const express = require('express');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const multer = require('multer');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const DATA = path.join(__dirname, 'data');
const UPLOADS = path.join(__dirname, 'uploads');
for (const dir of [DATA, UPLOADS]) if (!fs.existsSync(dir)) fs.mkdirSync(dir, {recursive:true});
const dbFile = path.join(DATA, 'store.json');
const readDB = () => {
  try { return JSON.parse(fs.readFileSync(dbFile,'utf8')); }
  catch { return {users:[], assets:[], settings:{siteName:'SKYWELLSTUDIO',announcement:'Welcome to SkywellStudio'}}; }
};
const writeDB = d => fs.writeFileSync(dbFile, JSON.stringify(d,null,2));
let db = readDB();
if (!db.users.some(u=>u.username === (process.env.OWNER_USERNAME || 'skywell_owner'))) {
  db.users.push({id:1, username:process.env.OWNER_USERNAME || 'skywell_owner',
    password:bcrypt.hashSync(process.env.OWNER_PASSWORD || 'GantiPasswordIni123!',10),
    role:'owner', active:true, createdAt:new Date().toISOString()});
  writeDB(db);
}
app.use(express.json({limit:'2mb'}));\napp.get('/health',(req,res)=>res.status(200).json({ok:true,service:'SKYWELLSTUDIO'}));
app.use(session({
  secret:process.env.SESSION_SECRET || 'development-only-change-this-secret',
  resave:false, saveUninitialized:false,
  cookie:{httpOnly:true, sameSite:'lax', secure:process.env.NODE_ENV==='production', maxAge:8*60*60*1000}
}));
app.use(express.static(path.join(__dirname,'public')));
const auth=(req,res,next)=>{ if(!req.session.user) return res.status(401).json({error:'Silakan login terlebih dahulu.'}); next(); };
const owner=(req,res,next)=>{ if(!req.session.user || req.session.user.role!=='owner') return res.status(403).json({error:'Akses khusus Owner.'}); next(); };

app.post('/api/login',(req,res)=>{
  const {username,password}=req.body||{};
  const user=db.users.find(u=>u.username===username && u.active);
  if(!user || !bcrypt.compareSync(password||'',user.password)) return res.status(401).json({error:'Username atau password salah.'});
  req.session.user={id:user.id,username:user.username,role:user.role};
  res.json({user:req.session.user});
});
app.post('/api/logout',(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get('/api/me',(req,res)=>res.json({user:req.session.user||null}));
app.get('/api/dashboard',auth,(req,res)=>res.json({
  user:req.session.user,
  stats:{audio:db.assets.filter(a=>a.kind==='audio').length,decals:db.assets.filter(a=>a.kind==='decal').length,
    skybox:db.assets.filter(a=>a.kind==='skybox').length,total:db.assets.length},
  assets:db.assets.slice().reverse().slice(0,30),
  settings:db.settings
}));
const storage=multer.diskStorage({destination:(req,file,cb)=>cb(null,UPLOADS),filename:(req,file,cb)=>cb(null,Date.now()+'-'+file.originalname.replace(/[^a-zA-Z0-9._-]/g,'_'))});
const upload=multer({storage,limits:{fileSize:50*1024*1024}});
app.post('/api/upload',auth,upload.single('file'),(req,res)=>{
  if(!req.file) return res.status(400).json({error:'Pilih file terlebih dahulu.'});
  const kind=req.body.kind;
  if(!['audio','decal','skybox','library'].includes(kind)) return res.status(400).json({error:'Jenis aset tidak valid.'});
  const asset={id:Date.now(),name:req.file.originalname,kind,size:req.file.size,
    file:'/uploads/'+req.file.filename,owner:req.session.user.username,createdAt:new Date().toISOString(),status:'Stored locally'};
  db.assets.push(asset); writeDB(db); res.json({asset});
});
app.use('/uploads',auth,express.static(UPLOADS));
app.delete('/api/assets/:id',auth,(req,res)=>{
  const id=Number(req.params.id), asset=db.assets.find(a=>a.id===id);
  if(!asset) return res.status(404).json({error:'Aset tidak ditemukan.'});
  if(req.session.user.role!=='owner' && asset.owner!==req.session.user.username) return res.status(403).json({error:'Tidak memiliki izin.'});
  db.assets=db.assets.filter(a=>a.id!==id);
  try { fs.unlinkSync(path.join(UPLOADS,path.basename(asset.file))); } catch {}
  writeDB(db); res.json({ok:true});
});
app.get('/api/owner/users',owner,(req,res)=>res.json({users:db.users.map(({id,username,role,active,createdAt})=>({id,username,role,active,createdAt}))}));
app.post('/api/owner/users',owner,(req,res)=>{
  const {username,password,role='member'}=req.body||{};
  if(!username || !password || password.length<8) return res.status(400).json({error:'Username dan password minimal 8 karakter wajib diisi.'});
  if(db.users.some(u=>u.username===username)) return res.status(409).json({error:'Username sudah digunakan.'});
  const id=Math.max(0,...db.users.map(u=>u.id))+1;
  db.users.push({id,username,password:bcrypt.hashSync(password,10),role:role==='admin'?'admin':'member',active:true,createdAt:new Date().toISOString()});
  writeDB(db); res.json({ok:true,id});
});
app.patch('/api/owner/users/:id',owner,(req,res)=>{
  const u=db.users.find(x=>x.id===Number(req.params.id));
  if(!u || u.role==='owner') return res.status(404).json({error:'Pengguna tidak ditemukan.'});
  if(typeof req.body.active==='boolean') u.active=req.body.active;
  if(['admin','member'].includes(req.body.role)) u.role=req.body.role;
  if(req.body.password && req.body.password.length>=8) u.password=bcrypt.hashSync(req.body.password,10);
  writeDB(db); res.json({ok:true});
});
app.delete('/api/owner/users/:id',owner,(req,res)=>{
  const id=Number(req.params.id),u=db.users.find(x=>x.id===id);
  if(!u || u.role==='owner') return res.status(400).json({error:'Akun Owner tidak dapat dihapus.'});
  db.users=db.users.filter(x=>x.id!==id); writeDB(db); res.json({ok:true});
});
app.patch('/api/owner/settings',owner,(req,res)=>{
  db.settings={...db.settings,siteName:String(req.body.siteName||'SKYWELLSTUDIO').slice(0,40),
    announcement:String(req.body.announcement||'').slice(0,180)};
  writeDB(db); res.json({settings:db.settings});
});
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.listen(PORT,()=>console.log(`SKYWELLSTUDIO berjalan di http://localhost:${PORT}`));
