# SKYWELLSTUDIO — Online deployment starter

## Jalankan lokal (Windows)
1. Install Node.js LTS.
2. Extract ZIP.
3. Salin `.env.example` menjadi `.env`.
4. Ubah `OWNER_USERNAME`, `OWNER_PASSWORD`, dan `SESSION_SECRET` dengan nilai rahasia milikmu.
5. Buka terminal pada folder proyek:
   ```bash
   npm install
   npm start
   ```
6. Buka `http://localhost:3000`.

## Deploy online (contoh: Render)
1. Buat akun GitHub dan Render.
2. Buat repository GitHub **private** dan upload isi folder proyek. Jangan upload `.env`, folder `data/`, `uploads/`, atau `node_modules/`.
3. Di Render, buat Web Service dari repository tersebut. Pilih Docker sebagai runtime.
4. Tambahkan persistent disk ke service, mount path `/app/data` untuk menyimpan database JSON lokal.
5. Isi environment variables `OWNER_USERNAME` dan `OWNER_PASSWORD` dengan kredensial kuat. `SESSION_SECRET` harus berupa random secret panjang; jangan gunakan contoh.
6. Deploy dan uji endpoint `/health`, login Owner, upload file, logout, dan login kembali.
7. Gunakan alamat subdomain gratis dari penyedia untuk pengujian. Custom domain dapat ditambahkan kemudian setelah domain dibeli dan DNS diarahkan ke hosting.

`render.yaml` adalah contoh konfigurasi awal. Periksa harga dan batas paket Render sebelum deploy; persistent disk dan service berbayar dapat dikenakan biaya.

## Fitur aktif pada starter
- Login/session dan akun Owner otomatis saat pertama kali dijalankan.
- Owner membuat akun Admin/Member, mengaktifkan/nonaktifkan dan menghapus akun.
- Upload file audio, gambar/decal, skybox, dan library ke penyimpanan lokal server (maks. 50 MB).
- Statistik dan pengelolaan aset.
- Pengaturan nama/pengumuman dasar.
- Health check `/health`.

## Batasan penting sebelum produksi
Ini belum siap dipakai sebagai layanan publik berskala besar dan belum diaudit keamanannya. Saat ini data pengguna/aset memakai JSON file; session memakai MemoryStore bawaan Express; validasi MIME/isi file, rate limiting, CSRF protection, audit log, password reset, email verification, dan backup otomatis belum tersedia. Sebelum menerima pengguna publik, migrasikan ke PostgreSQL, gunakan session store persisten (misalnya Redis/PostgreSQL), tambah proteksi keamanan dan backup, batasi jenis file dengan pemeriksaan konten, serta uji pemulihan data.

Aplikasi saat ini **tidak mengunggah/mempublikasikan aset ke Roblox**. Upload menyimpan file pada server sendiri. Integrasi Roblox Open Cloud/API memerlukan API key yang disimpan di server, izin sesuai, dan implementasi terpisah. Modul Spoof dan R6/R15 masih berupa placeholder UI.

Jangan pernah kirim password Owner, API key, atau `.env` melalui chat. Simpan rahasia hanya di dashboard Environment Variables hosting.
